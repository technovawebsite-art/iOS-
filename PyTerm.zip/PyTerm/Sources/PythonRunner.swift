import Foundation

/// Thread dedie avec grosse pile : Python y tourne toujours (init + executions).
private final class Worker: Thread {
    private let cond = NSCondition()
    private var jobs: [() -> Void] = []

    override func main() {
        while true {
            cond.lock()
            while jobs.isEmpty { cond.wait() }
            let job = jobs.removeFirst()
            cond.unlock()
            job()
        }
    }

    func submit(_ job: @escaping () -> Void) {
        cond.lock()
        jobs.append(job)
        cond.signal()
        cond.unlock()
    }
}

final class PythonRunner: ObservableObject {
    @Published var output = "Initialisation de Python…\n"
    @Published var ready = false
    @Published var isRunning = false

    private let worker = Worker()

    init() {
        worker.stackSize = 16 * 1024 * 1024
        worker.qualityOfService = .userInitiated
        worker.start()

        let base = Bundle.main.bundlePath
        worker.submit {
            let rc = py_bridge_init(base + "/python", base + "/app", base + "/app_packages")
            DispatchQueue.main.async {
                if rc == 0 {
                    self.ready = true
                    self.output = "Python prêt.\n"
                } else {
                    self.output = "Échec de l’initialisation de Python (code \(rc)).\n"
                }
            }
        }
    }

    func run(_ code: String) {
        isRunning = true
        worker.submit {
            var text = ""
            if let ptr = py_bridge_run(code) {
                text = String(cString: ptr)
                py_bridge_free(ptr)
            }
            DispatchQueue.main.async {
                self.output += text
                self.isRunning = false
            }
        }
    }
}
