#ifndef PYBRIDGE_H
#define PYBRIDGE_H

// 0 = OK. Doit etre appele depuis le thread qui executera ensuite le code.
int py_bridge_init(const char *home, const char *app, const char *app_packages);
// Execute du code Python, renvoie stdout+stderr (a liberer avec py_bridge_free).
char *py_bridge_run(const char *code);
void py_bridge_free(char *p);

#endif
