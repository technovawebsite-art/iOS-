import SwiftUI

struct ContentView: View {
    @StateObject private var py = PythonRunner()
    @State private var code = """
import sys
print(sys.version)
for i in range(3):
    print("Hello iOS", i)
"""

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("PyTerm").font(.headline)
                Spacer()
                Button("Effacer") { py.output = "" }
                Button {
                    py.run(code)
                } label: {
                    Label("Exécuter", systemImage: "play.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(!py.ready || py.isRunning)
            }
            .padding()

            TextEditor(text: $code)
                .font(.system(.body, design: .monospaced))
                .padding(.horizontal, 8)

            Divider()

            ScrollView {
                Text(py.output)
                    .font(.system(.footnote, design: .monospaced))
                    .foregroundColor(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(8)
                    .textSelection(.enabled)
            }
            .frame(maxHeight: .infinity)
            .background(Color.black)
        }
    }
}
