#include <Python/Python.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pybridge.h"

static const char *BOOTSTRAP =
"import sys, io, traceback, contextlib\n"
"_g = {'__name__': '__main__'}\n"
"def _pyterm_run(code):\n"
"    buf = io.StringIO()\n"
"    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):\n"
"        try:\n"
"            exec(compile(code, '<terminal>', 'exec'), _g)\n"
"        except BaseException:\n"
"            traceback.print_exc()\n"
"    return buf.getvalue()\n";

int py_bridge_init(const char *home, const char *app, const char *app_packages) {
    PyStatus status;
    PyPreConfig preconfig;
    PyConfig config;

    PyPreConfig_InitIsolatedConfig(&preconfig);
    preconfig.utf8_mode = 1;
    status = Py_PreInitialize(&preconfig);
    if (PyStatus_Exception(status)) return 1;

    PyConfig_InitIsolatedConfig(&config);
    config.write_bytecode = 0;
    config.buffered_stdio = 0;
    status = PyConfig_SetBytesString(&config, &config.home, home);
    if (PyStatus_Exception(status)) { PyConfig_Clear(&config); return 2; }

    status = Py_InitializeFromConfig(&config);
    PyConfig_Clear(&config);
    if (PyStatus_Exception(status)) return 3;

    char paths[4096];
    snprintf(paths, sizeof(paths),
             "import sys\nsys.path.insert(0, '%s')\nsys.path.insert(0, '%s')\n",
             app_packages, app);
    if (PyRun_SimpleString(paths) != 0) return 4;
    if (PyRun_SimpleString(BOOTSTRAP) != 0) return 5;
    return 0;
}

char *py_bridge_run(const char *code) {
    PyObject *main_mod = PyImport_AddModule("__main__"); /* emprunte */
    PyObject *fn = main_mod ? PyObject_GetAttrString(main_mod, "_pyterm_run") : NULL;
    if (!fn) { PyErr_Clear(); return strdup("Erreur interne : bootstrap absent\n"); }

    PyObject *arg = PyUnicode_FromString(code);
    PyObject *res = arg ? PyObject_CallFunctionObjArgs(fn, arg, NULL) : NULL;

    char *out;
    if (res && PyUnicode_Check(res)) {
        const char *s = PyUnicode_AsUTF8(res);
        out = strdup(s ? s : "");
    } else {
        PyErr_Print();
        out = strdup("Erreur interne pendant l'execution\n");
    }
    Py_XDECREF(res);
    Py_XDECREF(arg);
    Py_DECREF(fn);
    return out;
}

void py_bridge_free(char *p) { free(p); }
