import SwiftUI
import UIKit

@main
struct PyTermApp: App {
    init() {
        // Evite que iOS remplace les guillemets/tirets dans le code.
        let tv = UITextView.appearance()
        tv.smartQuotesType = .no
        tv.smartDashesType = .no
        tv.smartInsertDeleteType = .no
        tv.autocorrectionType = .no
        tv.autocapitalizationType = .none
    }

    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
