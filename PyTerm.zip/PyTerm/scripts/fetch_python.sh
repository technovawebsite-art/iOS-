#!/bin/bash
# Telecharge Python.xcframework (BeeWare Python-Apple-support) a la racine du projet.
set -euo pipefail
PY_SERIES="${PY_SERIES:-3.13}"

if [ -z "${PYTHON_SUPPORT_URL:-}" ]; then
  PYTHON_SUPPORT_URL=$(curl -fsSL \
    "https://api.github.com/repos/beeware/Python-Apple-support/releases?per_page=40" \
    | python3 -c '
import json, sys
serie = sys.argv[1]
for r in json.load(sys.stdin):
    for a in r["assets"]:
        n = a["name"]
        if n.startswith("Python-%s-iOS-support" % serie) and n.endswith(".tar.gz"):
            print(a["browser_download_url"]); sys.exit(0)
sys.exit("Archive Python-Apple-support introuvable pour " + serie)
' "$PY_SERIES")
fi

echo "Telechargement : $PYTHON_SUPPORT_URL"
curl -fsSL "$PYTHON_SUPPORT_URL" -o /tmp/python-support.tar.gz
tar -xzf /tmp/python-support.tar.gz -C .
test -d Python.xcframework
test -f Python.xcframework/build/utils.sh
echo "Python.xcframework OK"
