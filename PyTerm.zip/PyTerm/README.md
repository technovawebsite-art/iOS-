# PyTerm — terminal Python pour iOS (SwiftUI + Codemagic)

1. Pousse ce dossier dans un depot Git (GitHub/GitLab/Bitbucket).
2. Codemagic > Add application > choisis le depot > "codemagic.yaml".
3. Dans codemagic.yaml, remplace NOM_DE_TON_PROFIL / NOM_DE_TON_CERTIFICAT
   (ou utilise l'integration App Store Connect) et le bundle id
   (com.example.pyterm) ici ET dans project.yml.
4. Lance le build : XcodeGen genere le projet, Python.xcframework est
   telecharge, l'IPA signee est dans les artefacts.

Limites : pas de vrai shell iOS (pas de subprocess, ls, pip). Le code est
execute par l'interpreteur embarque. Ajoute des modules dans app/ et des
paquets Python purs dans app_packages/.
