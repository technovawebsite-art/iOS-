Mets ici des paquets Python purs (pip install --target app_packages ...).
