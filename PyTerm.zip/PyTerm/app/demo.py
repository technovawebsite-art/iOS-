# Place tes propres modules Python ici : ils sont importables avec `import demo`.
def hello():
    return "Bonjour depuis app/demo.py"
